<template>
    <v-layout column>
        <chart-component></chart-component>
    </v-layout>
</template>

<script>
    module.exports = {}
</script>

<style scoped>

</style>
<template>
    <v-layout column>
        <v-img src="../assets/help.jpg" class="lighten-2">
            <v-layout class="mt-5" align-center justify-center fill-height column>
                <p class="display-1 text-xs-center">We live in</p>
                <p class="indigo--text display-1 text-xs-center">https://we-are-devworker.slack.com</p>
                <p class="display-1 text-xs-center">We Working On</p>
                <p class="indigo--text display-1 text-xs-center">
                    https://github.com/incheol1024/kns/tree/master/teamKMS</p>
                <p class="display-1 text-xs-center">We Wait Dev-Worker Like You</p>
                <p class="display-1 text-xs-center">Please Message To Us</p>
            </v-layout>
        </v-img>
    </v-layout>
</template>

<script>
    module.exports = {
        data: () => ({}),
        methods: {}
    }
</script>